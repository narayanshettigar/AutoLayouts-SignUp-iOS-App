//
//  ViewController.swift
//  AutoLayout-SignUP
//
//  Created by Cumulations on 31/05/23.
//

import UIKit

class ViewController: UIViewController {
    
    let bgImageView = UIImageView()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setBG()
    }
    
    func setBG() {
        view.addSubview(bgImageView)
        // making this fasle lets the Xcode knows that you are going to use AutoLayouts
        bgImageView.translatesAutoresizingMaskIntoConstraints = false
        bgImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        bgImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        bgImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        bgImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        
        bgImageView.image = UIImage(named: "bgGAME")
        // this sends the image back of everything in the view heirchy
        
        view.sendSubviewToBack(bgImageView)
    }
}
